package ejercicio3;

public class Cadenas {
	public static String[] validarDni(String[] dni, char letra, int longitud) {
		longitud = 9;
		dni = new String[longitud];
		
		System.out.println(dni.length);
		
		return dni;
	}
}
